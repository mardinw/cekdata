export interface DataImport {
    id: number;
    nama: string;
    ttl: string;
    alamat: string;
    kecamatan: string;
    kelurahan: string;
    file: string;
    users: string;
    gender: string;
}